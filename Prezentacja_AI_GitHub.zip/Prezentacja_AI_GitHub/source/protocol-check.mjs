import assert from 'node:assert/strict';
import mqtt from 'mqtt';
import { SlideLink } from './src/slide-link.ts';
// Negative tests target only the isolated random session created below.
// No existing presentation or third-party topic is read or modified.
let observed;
const host = new SlideLink('display', 28, { state: s => { observed = s; }, online: () => {}, error: () => {} });
const remote = new SlideLink('remote', 28, { state: () => {}, online: () => {}, error: () => {} });
let probe;
const timeout = setTimeout(() => { console.error('Protocol check timed out'); process.exit(1); }, 45000);
const until = async predicate => { const end = Date.now() + 6000; while (!predicate()) { if (Date.now() > end) throw new Error('State confirmation timed out'); await new Promise(r => setTimeout(r, 25)); } };
try {
 const pair = await host.host(0);
 const connected = await remote.join(pair.code, pair.token);
 assert.equal(connected.slide, 0);
 assert.equal((await remote.command('next')).slide, 1);
 const topic = 'pcz/ai-pages/v3/' + Buffer.from(await crypto.subtle.digest('SHA-256', new TextEncoder().encode('pcz-ai-pages-v3:' + pair.token))).toString('hex');
 probe = mqtt.connect('wss://broker.emqx.io:8084/mqtt', { clientId: 'pcz-check-' + crypto.randomUUID().slice(0,8), reconnectPeriod: 0, connectTimeout: 6000 });
 await new Promise((resolve,reject) => { probe.on('connect',resolve); probe.on('error',reject); });
 const publish = body => new Promise((resolve,reject) => probe.publish(topic,body,{qos:1,retain:false},error=>error?reject(error):resolve()));
 const key = await crypto.subtle.importKey('raw', Buffer.from(pair.token,'hex'), 'AES-GCM',false,['encrypt']);
 const packet = async (value, chosenKey = key) => {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const data = await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:new TextEncoder().encode(topic)},chosenKey,new TextEncoder().encode(JSON.stringify(value)));
  return JSON.stringify({iv:Buffer.from(iv).toString('base64'),data:Buffer.from(data).toString('base64')});
 };
 const base = {kind:'command',sender:crypto.randomUUID(),at:Date.now(),action:'goto',slide:19};
 await publish(JSON.stringify({...base,id:crypto.randomUUID()}));
 await publish(await packet({...base,id:crypto.randomUUID(),at:Date.now()-60000}));
 const wrongKey = await crypto.subtle.generateKey({name:'AES-GCM',length:256},false,['encrypt']);
 await publish(await packet({...base,id:crypto.randomUUID()},wrongKey));
 const duplicate = await packet({...base,action:'next',slide:undefined,id:crypto.randomUUID()});
 await publish(duplicate); await publish(duplicate);
 await until(()=>observed.slide === 2);
 assert.equal((await remote.command('next')).slide, 3);
 assert.equal(observed.version, 3);
 assert.equal((await remote.command('goto',28)).slide,28);
 assert.equal((await remote.command('next')).slide,28);
 assert.equal((await remote.command('previous')).slide,27);
 console.log('PASS: real relay connection, confirmed commands, duplicate suppression, malformed and unauthenticated message rejection, stale replay rejection, slide bounds.');
} finally {
 clearTimeout(timeout); host.dispose(); remote.dispose(); probe?.end(true);
}
