export function Icon({ kind }: { kind: string }) {
  const paths: Record<string, React.ReactNode> = {
    data: <><path d="M7 5h14l5 5v21H7zM21 5v6h5M12 17h9M12 22h9M12 27h6" /></>,
    person: <><circle cx="18" cy="11" r="6" /><path d="M6 31v-3a12 12 0 0 1 24 0v3M14 23l4 4 4-4" /></>,
    publish: <><path d="M8 14v11h7l14 6V8l-14 6zM11 25l3 7M29 15h4M29 23h4" /></>,
    copies: <><path d="M12 6h18v24H12zM6 12v22h18M17 13h8M17 19h8M17 25h5" /></>,
    train: <><circle cx="18" cy="18" r="11" /><circle cx="18" cy="18" r="4" /><path d="M18 2v5M18 29v5M2 18h5M29 18h5M7 7l4 4M25 25l4 4M7 29l4-4M25 11l4-4" /></>,
    image: <><rect x="5" y="6" width="26" height="24" rx="1" /><circle cx="23" cy="13" r="3" /><path d="M5 27l9-11 7 8 4-4 6 7" /></>,
    edit: <><path d="M7 27l-1 6 6-1 20-20-5-5zM23 11l5 5M6 33h26" /></>,

    book: <><path d="M18 8v24M18 8C13 5 8 4 3 5v24c5-1 10 0 15 3M18 8c5-3 10-4 15-3v24c-5-1-10 0-15 3M7 12l6 2M7 18l6 2M23 14l6-2M23 20l6-2" /></>,
    music: <><path d="M13 26V9l17-4v17M13 14l17-4" /><ellipse cx="8" cy="27" rx="5" ry="4" /><ellipse cx="25" cy="23" rx="5" ry="4" /></>,
    court: <><path d="M18 4v28M8 32h20M5 10h26M9 10l-5 10h10zM27 10l-5 10h10z" /><circle cx="18" cy="7" r="2" /></>,
    contract: <><path d="M7 4h19v28H7zM12 10h9M12 16h9M12 22h4M20 29l3-7 7-7 4 4-7 7z" /></>,
    money: <><circle cx="18" cy="18" r="14" /><path d="M23 11h-7a4 4 0 0 0 0 8h4a4 4 0 0 1 0 8h-7M18 7v24" /></>,
    bulb: <><path d="M12 25h12M13 29h10M15 33h6M12 21a10 10 0 1 1 12 0v4H12zM18 2v3M2 14h3M31 14h3M5 5l3 3M28 8l3-3" /></>,
    calendar: <><rect x="5" y="7" width="26" height="25" rx="2" /><path d="M5 15h26M11 3v8M25 3v8M11 21h4M21 21h4M11 27h4" /></>,
    shield: <><path d="M18 3l13 5v10c0 7-6 12-13 15C11 30 5 25 5 18V8zM11 17l5 5 10-11" /></>,
    layout: <><rect x="4" y="5" width="28" height="26" rx="2" /><path d="M4 13h28M15 13v18M20 19h7M20 25h7M9 19v7" /></>,
    cross: <><circle cx="18" cy="18" r="14" /><path d="M12 12l12 12M24 12L12 24" /></>,
    check: <><path d="M7 18l7 7L30 9" /></>,
  };
  return <svg className="diagram-icon" width="36" height="36" viewBox="0 0 36 36" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[kind] || paths.data}</svg>;
}
