import mqtt, { type MqttClient } from 'mqtt';
export type Session = { code: string; token: string; slide: number; blank: boolean; version: number };
export type Action = 'next' | 'previous' | 'goto' | 'blank';
type PublicState = Omit<Session, 'token'>;
type Events = { state: (s: Session) => void; online: (v: boolean) => void; error: (message: string) => void };
type Packet = { kind: 'hello' | 'state' | 'command'; sender: string; at: number; id?: string; action?: Action; slide?: number; state?: PublicState; ack?: string };
const storageKey = 'pcz-ai-pages-host-v3';
const brokers = ['wss://broker.emqx.io:8084/mqtt', 'wss://test.mosquitto.org:8081/mqtt'];
const record = (v: unknown): v is Record<string, unknown> => Boolean(v) && typeof v === 'object' && !Array.isArray(v);
const validToken = (v: unknown): v is string => typeof v === 'string' && /^[a-f0-9]{64}$/.test(v);
const hex = (b: Uint8Array) => [...b].map(v => v.toString(16).padStart(2, '0')).join('');
const b64 = (b: Uint8Array) => btoa(String.fromCharCode(...b));
const unb64 = (s: string) => Uint8Array.from(atob(s), c => c.charCodeAt(0));
function validState(v: unknown, last: number): v is PublicState {
  return record(v) && typeof v.code === 'string' && /^\d{6}$/.test(v.code) && Number.isInteger(v.slide) && Number(v.slide) >= 0 && Number(v.slide) <= last && typeof v.blank === 'boolean' && Number.isSafeInteger(v.version) && Number(v.version) >= 0;
}
export function storedHost(last: number): Session | null {
  try { const v: unknown = JSON.parse(sessionStorage.getItem(storageKey) || 'null'); return validState(v, last) && validToken((v as Session).token) ? v as Session : null; } catch { return null; }
}
export function credentials(raw: string) {
  try {
    const url = new URL(raw), code = url.searchParams.get('kod'), token = new URLSearchParams(url.hash.slice(1)).get('klucz');
    if (url.origin === location.origin && url.pathname.endsWith('/pilot.html') && /^\d{6}$/.test(code || '') && validToken(token)) return { code: code!, token };
  } catch { /* Short codes are not authentication credentials. */ }
  throw new Error('Zeskanuj kod QR z komputera albo wklej pełny link do pilota, razem z częścią po znaku #.');
}
const failure = 'Nie udało się połączyć. Pozostaw prezentację otwartą i sprawdź internet. W sieci uczelnianej spróbuj hotspotu telefonu.';

// Each room requires a cryptographically random 256-bit key, shared ONLY via
// the QR/link URL fragment. The six-digit label cannot authenticate commands.
// Relays see AES-256-GCM ciphertext and a hash topic; never plaintext or keys.
// Authenticated decryption precedes all command handling. IDs deduplicate
// delivery across two relays; timestamps reject stale replayed commands.
export class SlideLink {
  private clients: MqttClient[] = [];
  private state: Session | null = null;
  private key: CryptoKey | null = null;
  private token = ''; private code = ''; private topic = '';
  private sender = crypto.randomUUID(); private disposed = false; private lastSeen = 0;
  private remotes = new Map<string, number>(); private seen = new Set<string>();
  private interval: ReturnType<typeof setInterval> | undefined;
  private opening: ReturnType<typeof setTimeout> | undefined;
  private initialReject: ((e: Error) => void) | undefined;
  private onState: ((s: Session) => void) | undefined;
  private pending = new Map<string, { resolve: (s: Session) => void; reject: (e: Error) => void; timer: ReturnType<typeof setTimeout> }>();
  constructor(private mode: 'display' | 'remote', private last: number, private events: Events) {}
  private update(state: Session) {
    this.state = state;
    if (this.mode === 'display') { try { sessionStorage.setItem(storageKey, JSON.stringify(state)); } catch { /* Open tab still owns state. */ } }
    this.events.state(state);
  }
  private async send(packet: Omit<Packet, 'sender' | 'at'>) {
    if (!this.key || this.disposed) return;
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const data = new TextEncoder().encode(JSON.stringify({ ...packet, sender: this.sender, at: Date.now() }));
    const cipher = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(this.topic) }, this.key, data);
    if (this.disposed) return;
    const body = JSON.stringify({ iv: b64(iv), data: b64(new Uint8Array(cipher)) });
    for (const client of this.clients) if (client.connected) client.publish(this.topic, body, { qos: 1, retain: false });
  }
  private sendState(ack?: string) {
    if (!this.state) return;
    const { code, slide, blank, version } = this.state;
    void this.send({ kind: 'state', state: { code, slide, blank, version }, ack });
  }
  private hostStatus() {
    for (const [id, at] of this.remotes) if (Date.now() - at > 45000) this.remotes.delete(id);
    this.events.online(this.clients.some(c => c.connected) && this.remotes.size > 0);
  }
  private async receive(body: string) {
    if (!this.key || this.disposed || body.length > 4096) return;
    try {
      const envelope: unknown = JSON.parse(body);
      if (!record(envelope) || typeof envelope.iv !== 'string' || typeof envelope.data !== 'string') return;
      const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(envelope.iv), additionalData: new TextEncoder().encode(this.topic) }, this.key, unb64(envelope.data));
      const value: unknown = JSON.parse(new TextDecoder().decode(plain));
      if (!record(value) || value.sender === this.sender || typeof value.sender !== 'string' || typeof value.at !== 'number' || Math.abs(Date.now() - value.at) > 30000) return;
      const p = value as unknown as Packet;
      if (this.mode === 'display') {
        if (p.kind === 'hello') { this.remotes.set(p.sender, Date.now()); this.hostStatus(); this.sendState(); }
        else if (p.kind === 'command' && typeof p.id === 'string' && p.id.length <= 100 && ['next', 'previous', 'goto', 'blank'].includes(String(p.action))) {
          if (p.action === 'goto' && (!Number.isInteger(p.slide) || Number(p.slide) < 0 || Number(p.slide) > this.last)) return;
          this.remotes.set(p.sender, Date.now()); this.hostStatus(); this.apply(p);
        }
      } else if (p.kind === 'state' && validState(p.state, this.last) && p.state.code === this.code) {
        const state = { ...p.state, token: this.token };
        this.lastSeen = Date.now(); this.events.online(true);
        if (!this.state || state.version >= this.state.version) this.update(state);
        this.onState?.(state);
        const item = p.ack ? this.pending.get(p.ack) : undefined;
        if (item) { clearTimeout(item.timer); this.pending.delete(p.ack!); item.resolve(state); }
      }
    } catch { /* Unauthenticated ciphertext, wrong keys and malformed data are discarded. */ }
  }
  private async start(code: string, token: string, ready: () => void) {
    this.code = code; this.token = token;
    this.key = await crypto.subtle.importKey('raw', Uint8Array.from(token.match(/../g)!, v => parseInt(v, 16)), 'AES-GCM', false, ['encrypt', 'decrypt']);
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`pcz-ai-pages-v3:${token}`));
    this.topic = 'pcz/ai-pages/v3/' + hex(new Uint8Array(digest));
    if (this.disposed) return;
    this.clients = brokers.map((url, i) => {
      const client = mqtt.connect(url, { clientId: `pcz-${crypto.randomUUID().slice(0, 8)}-${i}`, protocolVersion: 4, clean: true, keepalive: 20, reconnectPeriod: 2000, connectTimeout: 6000, queueQoSZero: false });
      client.on('connect', () => client.subscribe(this.topic, { qos: 1 }, error => {
        if (error || this.disposed) return;
        ready(); if (this.mode === 'remote') void this.send({ kind: 'hello' }); else this.sendState();
      }));
      client.on('message', (topic, payload) => { if (topic === this.topic) void this.receive(payload.toString()); });
      client.on('error', () => { /* Independent relay and automatic reconnect remain active. */ });
      client.on('offline', () => { if (!this.disposed && !this.clients.some(c => c.connected)) this.events.online(false); });
      return client;
    });
    this.interval = setInterval(() => {
      if (this.disposed) return;
      if (this.mode === 'remote') { void this.send({ kind: 'hello' }); if (Date.now() - this.lastSeen > 40000) this.events.online(false); }
      else this.hostStatus();
    }, 15000);
  }
  async host(slide: number, restore?: Session) {
    const code = restore?.code || String(100000 + crypto.getRandomValues(new Uint32Array(1))[0] % 900000);
    const token = restore?.token || hex(crypto.getRandomValues(new Uint8Array(32)));
    const state = restore || { code, token, slide, blank: false, version: 0 }; this.update(state);
    return new Promise<Session>((resolve, reject) => {
      let settled = false; this.initialReject = reject;
      this.opening = setTimeout(() => { if (!settled) { settled = true; reject(new Error(failure)); } }, 14000);
      void this.start(code, token, () => { if (!settled) { settled = true; clearTimeout(this.opening); this.initialReject = undefined; resolve(state); } }).catch(reject);
    });
  }
  async join(code: string, token: string) {
    if (!/^\d{6}$/.test(code) || !validToken(token)) throw new Error('Brakuje klucza parowania. Zeskanuj kod QR.');
    return new Promise<Session>((resolve, reject) => {
      let settled = false; this.initialReject = reject;
      this.opening = setTimeout(() => { if (!settled) { settled = true; reject(new Error(failure)); } }, 16000);
      this.onState = state => { if (!settled) { settled = true; clearTimeout(this.opening); this.initialReject = undefined; resolve(state); } };
      void this.start(code, token, () => {}).catch(reject);
    });
  }
  private apply(p: Packet) {
    if (!this.state || !p.id) return;
    if (!this.seen.has(p.id)) {
      this.seen.add(p.id); if (this.seen.size > 256) this.seen.delete(this.seen.values().next().value!);
      const state = { ...this.state, version: this.state.version + 1 };
      if (p.action === 'next') state.slide = Math.min(this.last, state.slide + 1);
      if (p.action === 'previous') state.slide = Math.max(0, state.slide - 1);
      if (p.action === 'goto') state.slide = p.slide!;
      if (p.action === 'blank') state.blank = !state.blank;
      this.update(state);
    }
    this.sendState(p.id);
  }
  command(action: Action, slide?: number): Promise<Session> {
    const id = crypto.randomUUID();
    if (this.mode === 'display') { this.apply({ kind: 'command', id, action, slide, sender: this.sender, at: Date.now() }); return this.state ? Promise.resolve(this.state) : Promise.reject(new Error('Najpierw połącz telefon.')); }
    if (!this.clients.some(c => c.connected)) return Promise.reject(new Error('Czekam na ponowne połączenie.'));
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(id); reject(new Error('Komputer nie potwierdził zmiany. Sprawdź połączenie.')); }, 6000);
      this.pending.set(id, { resolve, reject, timer }); void this.send({ kind: 'command', id, action, slide });
    });
  }
  dispose() {
    this.disposed = true; clearInterval(this.interval); clearTimeout(this.opening);
    this.initialReject?.(new Error('Połączenie zakończone.')); this.initialReject = undefined;
    for (const item of this.pending.values()) { clearTimeout(item.timer); item.reject(new Error('Połączenie zakończone.')); }
    this.pending.clear(); for (const client of this.clients) client.end(true); this.clients = [];
  }
  forget() { this.dispose(); try { sessionStorage.removeItem(storageKey); } catch { /* No stored session. */ } }
}
