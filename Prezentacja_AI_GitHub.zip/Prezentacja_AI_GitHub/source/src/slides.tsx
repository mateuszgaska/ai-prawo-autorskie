import { Fragment, useEffect, useRef, useState } from 'react';
import content from './content.json';
import { Icon } from './slide-icons';
import theatreUrl from './assets/theatre1.jpg';
import zaryaUrl from './assets/zarya1.png';
import innovationUrl from './assets/innovation-city.jpg';
export const slides = content.slides;
export const slidesCount = slides.length;
export const sources = content.sources;
export const time = (n: number) => `${Math.floor(n / 60).toString().padStart(2, '0')}:${(n % 60).toString().padStart(2, '0')}`;
type SlideData = typeof slides[number];
const pairs = (slide: SlideData) => slide.body as string[][];
const rowIcons: Record<number, string[]> = {4:['data','bulb','person','contract'],9:['edit','layout','edit'],11:['contract','calendar','shield'],12:['person','train','shield','contract'],13:['court','data','court'],17:['image','copies','image'],18:['image','image','book'],20:['contract','money','person'],22:['edit','image','money','publish']};

function Connector({ compare = false, plus = false }: { compare?: boolean; plus?: boolean }) {
  return <span className="card-connector" aria-hidden="true">{plus ? <span>+</span> : compare ? <span>≠</span> : <svg width="26" height="26" viewBox="0 0 26 26" fill="none"><path d="M3 13h19M15 6l7 7-7 7" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></svg>}</span>;
}
function Cards({ rows, icons, arrows = false, compare = false, plus = false }: { rows: string[][]; icons: string[]; arrows?: boolean; compare?: boolean; plus?: boolean }) {
  const linked = arrows || compare || plus;
  const columns = linked ? Array.from({length:rows.length * 2 - 1},(_,i)=>i % 2 ? '32px' : 'minmax(0,1fr)').join(' ') : `repeat(${rows.length},minmax(0,1fr))`;
  return <div className={`card-grid ${linked ? 'is-linked' : ''}`} style={{gridTemplateColumns:columns}}>{rows.map((r,i)=><Fragment key={i}><section className="diagram-card"><span className="card-number">0{i+1}</span><Icon kind={icons[i] || 'data'} /><h3>{r[0]}</h3><div className="card-lines">{r.slice(1).map((v,j)=><p key={j}>{v}</p>)}</div></section>{linked && i < rows.length-1 && <Connector compare={compare} plus={plus} />}</Fragment>)}</div>;
}
function MainQuestion({ slide, answer = false }: { slide: SlideData; answer?: boolean }) {
  return <div className="research-scene"><section className="research-question"><Icon kind={answer ? 'check' : 'bulb'} /><div><span>{answer ? 'Odpowiedź na pytanie badawcze' : 'Pytanie badawcze'}</span><p>{slide.lead}</p></div></section><Cards rows={pairs(slide)} icons={['data','person','publish']} arrows /></div>;
}
function BeforeAfter() {
  return <div className="before-after">
    <section className="project-example">
      <h3>Ilustracja z AI</h3>
      <figure className="project-canvas project-before"><img src={innovationUrl} alt="Ilustracja wygenerowana przez AI: futurystyczne miasto o zachodzie słońca" /></figure>
      <p className="project-caption">Materiał do dalszej pracy</p>
    </section>
    <Connector />
    <section className="project-example">
      <h3>Plakat po opracowaniu</h3>
      <div className="project-workspace">
        <div className="designed-poster" aria-label="Przykładowy plakat Noc innowacji z wykorzystaniem tej samej ilustracji">
          <span className="poster-series">SPOTKANIA Z PRZYSZŁOŚCIĄ</span>
          <h3>Noc innowacji</h3>
          <div className="designed-image"><img src={innovationUrl} alt="Ta sama ilustracja jako element kompozycji plakatu" /></div>
          <p>Jutro zaczyna się od pomysłu.</p>
          <span className="poster-details">WYKŁADY / WARSZTATY / ROZMOWY</span>
        </div>
        <ol className="project-annotations">
          {[['edit','Tekst','Autorskie hasło'],['layout','Kompozycja','Układ i hierarchia'],['image','Opracowanie','Kadr i elementy']].map(([icon,title,description],i)=><li key={title}><span className="annotation-number">0{i+1}</span><div><Icon kind={icon} /><strong>{title}</strong><span>{description}</span></div></li>)}
        </ol>
      </div>
      <p className="project-caption">Wskazujemy decyzje człowieka</p>
    </section>
  </div>;
}
function CompactFlow({ rows, icons }: { rows: string[][]; icons: string[] }) {
  return <div className="compact-flow">{rows.map((row,i)=><Fragment key={row[0]}><section className="compact-step"><Icon kind={icons[i]} /><div><h3>{row[0]}</h3>{row.slice(1).map(line=><p key={line}>{line}</p>)}</div></section>{i<rows.length-1 && <Connector />}</Fragment>)}</div>;
}
function TdmExample({ slide }: { slide: SlideData }) {
  return <div className="tdm-scene"><CompactFlow rows={[
    ['Materiały','Tysiące artykułów'],['Analiza','Szukanie wzorców'],['Wynik','Trendy i zależności']
  ]} icons={['copies','train','data']} /><Evidence slide={slide} /></div>;
}
function MusicCase({ slide }: { slide: SlideData }) {
  return <div className="music-scene">
    <section className="music-example"><Icon kind="music" /><div><h3>Forever Young</h3><p>Jeden z sześciu utworów w sprawie</p></div><span>GEMA przeciwko Suno</span></section>
    <CompactFlow rows={pairs(slide)} icons={['data','music','court']} />
    <section className="music-detail"><Icon kind="bulb" /><strong>Ciekawostka</strong><p>{slide.curiosityShort}</p></section>
  </div>;
}
function Evidence({ slide }: { slide: SlideData }) {
  return <table className="evidence-table" aria-label={slide.lead || slide.title}><thead><tr>{slide.tableHead.map((v,i)=><th key={i} scope="col"><span className="table-label"><Icon kind={['data','train','check'][i]} /><span>{v}</span></span></th>)}</tr></thead><tbody>{pairs(slide).map((r,i)=><tr key={i}>{r.map((v,j)=>j===0 ? <th key={j} scope="row"><span className="table-label"><Icon kind={rowIcons[slide.number]?.[i] || 'data'} /><span>{v}</span></span></th> : <td key={j}><span className="cell-text">{v}</span></td>)}</tr>)}</tbody></table>;
}
function DecisionStack({ rows, icons, statuses = false }: { rows: string[][]; icons: string[]; statuses?: boolean }) {
  return <div className="decision-stack" style={{gridTemplateRows:`repeat(${rows.length},minmax(0,1fr))`}}>{rows.map((r,i)=><section className="decision-card" key={i}><Icon kind={icons[i] || 'data'} /><div><h3>{r[0]}</h3><p className={statuses ? i===2 ? 'negative' : 'positive' : ''}>{r[1]}</p>{r[2] && <p>{r[2]}</p>}</div></section>)}</div>;
}
function RefList({ slide }: { slide: SlideData }) {
  return <div className="reference-grid">{pairs(slide).map((r,i)=>{const ids=r[0].match(/\d+/g)?.map(Number)||[];return <section className="reference-card" key={i}><Icon kind={[4,8,9].includes(ids[0]) ? 'court' : 'data'} /><span className="reference-id">{r[0]}</span><div><a href={sources.find(s=>s.id===ids[0])?.url} target="_blank" rel="noreferrer">{r[1]}</a>{ids.length>1 && <a className="second-source" href={sources.find(s=>s.id===ids[1])?.url} target="_blank" rel="noreferrer">Dokument ugody</a>}</div></section>;})}</div>;
}
export function Slide({ index, preview = false }: { index: number; preview?: boolean }) {
  const d=slides[index],rows=pairs(d);let body:React.ReactNode;
  switch(d.layout){
    case 'cover': body=<div className="academic-cover"><div className="university-row"><strong>{content.institution}</strong><div><span>{content.programme}</span><small>{content.semester}</small></div></div><h1>Sztuczna inteligencja<br /><em>a prawa autorskie</em></h1><div className="academic-byline"><div><span>Autor prezentacji</span><strong>Mateusz Gąska</strong></div><div><span>Przedmiot</span><strong>Ochrona własności intelektualnej</strong></div></div></div>;break;
    case 'agenda': body=<ol className="agenda-list">{rows.map((r,i)=><li key={i}><span className="agenda-symbol"><span>0{i+1}</span><Icon kind={['person','image','train','publish','check'][i]} /></span><h3>{r[0]}</h3><p>{r[1]}</p></li>)}</ol>;break;
    case 'research': body=<MainQuestion slide={d} />;break;
    case 'beforeafter': body=<BeforeAfter />;break;
    case 'tdm': body=<TdmExample slide={d} />;break;
    case 'evidence': body=<Evidence slide={d} />;break;
    case 'human': body=<Cards rows={rows} icons={['data','edit']} compare />;break;
    case 'artcase': body=<div className="case-media case-story"><figure><div className="case-image"><img src={theatreUrl} alt="Théâtre D’opéra Spatial, Jason M. Allen i Midjourney" /></div><figcaption><span>{d.caption}</span><strong>{d.curiosityShort}</strong></figcaption></figure><DecisionStack rows={rows} icons={['image','contract','court']} /></div>;break;
    case 'comic': body=<div className="case-media case-story"><figure><div className="case-image"><img src={zaryaUrl} alt="Strona komiksu Zarya of the Dawn z decyzji USCO" /></div><figcaption><span>{d.caption}</span><strong>{d.curiosityShort}</strong></figcaption></figure><DecisionStack rows={rows} icons={['edit','layout','image']} statuses /></div>;break;
    case 'prompt': body=<Cards rows={rows} icons={['data','train','edit']} arrows />;break;
    case 'training': body=<Cards rows={rows} icons={['data','copies','train','image']} arrows />;break;
    case 'aiact': body=<div className="act-scene"><div className="act-panels">{rows.map((r,i)=><section className="act-card" key={i}><Icon kind={i?'data':'shield'} /><div><h3>{r[0]}</h3>{r.slice(1).map((v,j)=><p key={j}>{v}</p>)}</div></section>)}</div><div className="dates-row">{[['2.08.2025','Obowiązki GPAI'],['2.08.2026','Egzekwowanie obowiązków'],['2.08.2027','Modele sprzed 2.08.2025']].map((r,i)=><section key={i}><Icon kind="calendar" /><div><h3>{r[0]}</h3><p>{r[1]}</p></div></section>)}</div></div>;break;
    case 'suno': body=<MusicCase slide={d} />;break;
    case 'bartz': body=<div className="bartz-scene"><DecisionStack rows={rows} icons={['court','copies']} /><section className="metric-card"><Icon kind="money" /><h3>Fundusz ugody</h3><strong className="metric-value">1,5 <span>mld USD</span></strong><p>Zatwierdzenie: 20.07.2026</p><p>Ugoda, nie kara sądowa</p></section></div>;break;
    case 'responsibility': body=<Cards rows={rows} icons={['train','person','publish']} arrows />;break;
    case 'case': body=<div className="poster-scene"><div className="example-poster"><span className="poster-label">Przykład hipotetyczny</span><h3>Spotkanie biznesowe</h3><div className="poster-photo"><Icon kind="image" /><p>Cudza fotografia</p><p>Przerobiona przez AI</p></div><h3>Idea na jutro</h3><p>Spotkajmy się dziś</p><span className="poster-label">Reklama płatnego wydarzenia</span></div><div className="poster-facts">{rows.map((r,i)=><section key={i}><Icon kind={['image','edit','publish','money'][i]} /><h3>{r[0]}</h3><p>{r[1]}</p></section>)}</div></div>;break;
    case 'position': body=<Cards rows={rows} icons={['court','bulb','money']} />;break;
    case 'budget': body=<Cards rows={rows} icons={['train','image','check','court']} plus />;break;
    case 'quiz': body=<div className="quiz-list">{rows.map((r,i)=><section key={i}><Icon kind={r[1]==='PRAWDA'?'check':'cross'} /><div><h3>{r[0]}</h3><p>{r[2]}</p></div><strong>{r[1]}</strong></section>)}</div>;break;
    case 'conclusion': body=<MainQuestion slide={d} answer />;break;
    case 'thanks': body=<div className="thank-you"><h1>Dziękuję za uwagę</h1></div>;break;
    case 'references': body=<RefList slide={d} />;break;
    default: body=<Evidence slide={d} />;
  }
  const closing = d.layout==='cover' || d.layout==='thanks';
  return <article className={`slide slide-${d.layout} slide-number-${index+1} ${preview?'is-preview':'is-animated'}`} aria-label={`Slajd ${index+1}: ${d.title.replace('\n',' ')}`}><header className="slide-header"><span className="slide-name">{d.kicker}</span><span className="slide-chapter">{String(d.number).padStart(2,'0')} / {slidesCount}</span></header>{!closing && <h2>{d.title}</h2>}<div className="slide-content">{body}</div>{!closing && <div className="slide-takeaway"><Icon kind="bulb" /><p>{d.takeaway}</p></div>}<footer className="slide-footer"><span className="slide-source">{d.foot}</span><span className="slide-author">Mateusz Gąska</span></footer></article>;
}
export function SlideFrame({ index, preview = false }: { index: number; preview?: boolean }) {
  const ref=useRef<HTMLDivElement>(null);const [scale,setScale]=useState(.5);
  useEffect(()=>{const el=ref.current;if(!el)return;const resize=()=>setScale(Math.min(el.clientWidth/1280,el.clientHeight/720));resize();const observer=new ResizeObserver(resize);observer.observe(el);return()=>observer.disconnect();},[]);
  return <div className={`slide-frame ${preview?'preview-frame':''}`} ref={ref}><div className="slide-scale" style={{transform:`translate(-50%, -50%) scale(${scale})`}}><Slide key={index} index={index} preview={preview} /></div></div>;
}
