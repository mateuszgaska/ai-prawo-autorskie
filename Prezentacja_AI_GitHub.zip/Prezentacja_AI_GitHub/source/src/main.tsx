import { createRoot } from 'react-dom/client';
import { PresentationApp } from './presentation-app';
import './globals.css';
const mode = /\/pilot(?:\.html)?\/?$/.test(location.pathname) ? 'remote' : 'display';
createRoot(document.getElementById('root')!).render(<PresentationApp mode={mode} />);
