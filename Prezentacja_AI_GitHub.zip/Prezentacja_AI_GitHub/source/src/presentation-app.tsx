import { useCallback, useEffect, useRef, useState } from 'react';
import { SlideFrame, slides, slidesCount, sources, time } from './slides';

import { SlideLink, storedHost, credentials, type Session, type Action } from './slide-link';
import { siteUrl } from './urls';
function Arrow({ left = false }: { left?: boolean }) { return <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true" style={{ transform: left ? 'rotate(180deg)' : undefined }}><path d="M4 12h15M13 5l7 7-7 7" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></svg>; }
function Expand() { return <svg width="19" height="19" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" /></svg>; }
function RehearsalTimer() {
  const [elapsed, setElapsed] = useState(0);
  const [running, setRunning] = useState(false);
  const accumulated = useRef(0);
  const started = useRef(0);
  const planned = slides.at(-1)?.end || 1800;
  useEffect(() => {
    if (!running) return;
    const timer = setInterval(() => setElapsed(Math.floor((accumulated.current + Date.now() - started.current) / 1000)), 250);
    return () => clearInterval(timer);
  }, [running]);
  function toggle() {
    if (running) {
      accumulated.current += Date.now() - started.current;
      setElapsed(Math.floor(accumulated.current / 1000));
      setRunning(false);
    } else { started.current = Date.now(); setRunning(true); }
  }
  function reset() { setRunning(false); accumulated.current = 0; setElapsed(0); }
  return <details className="rehearsal-timer"><summary>Próba na czas <output aria-live="off">{time(elapsed)} / {time(planned)}</output></summary><p>Przećwicz wystąpienie na głos. Stoper mierzy także pauzy i zmianę slajdów.</p><div className="rehearsal-actions"><button className="primary-button" aria-pressed={running} onClick={toggle}>{running ? 'Pauza' : elapsed ? 'Wznów próbę' : 'Rozpocznij próbę'}</button><button onClick={reset}>Wyzeruj</button></div></details>;
}
export function PresentationApp({ mode }: { mode: 'display' | 'remote' }) {
  const [session, setSession] = useState<Session | null>(null);
  const [localIndex, setLocalIndex] = useState(0);
  const [error, setError] = useState(''); const [online, setOnline] = useState(false);
  const [busy, setBusy] = useState(false); const [pending, setPending] = useState(false);
  const [panel, setPanel] = useState<'pair' | 'overview' | null>(null);
  const [input, setInput] = useState(''); const [copyLabel, setCopyLabel] = useState('Kopiuj link do pilota');
  const [qr, setQr] = useState(''); const [noteSize, setNoteSize] = useState(18);
  const [fullscreen, setFullscreen] = useState(false);
  const linkRef = useRef<SlideLink | null>(null);
  const sessionRef = useRef<Session | null>(null); const commandQueue = useRef(Promise.resolve()); const commandCount = useRef(0);
  const root = useRef<HTMLDivElement>(null); const initial = useRef(false); const noteTop = useRef<HTMLElement>(null);
  const index = session?.slide ?? localIndex; const d = slides[index];
  const pilotHref = siteUrl(`pilot.html${session ? '?kod=' + session.code + '#klucz=' + session.token : ''}`);
  const accept = useCallback((s: Session) => {
    if (sessionRef.current && sessionRef.current.code === s.code && sessionRef.current.version > s.version) return;
    setError('');
    if (sessionRef.current?.code === s.code && sessionRef.current.version === s.version) return;
    sessionRef.current = s; setSession(s);
  }, []);
  const newLink = useCallback(() => {
    linkRef.current?.dispose();
    const link = new SlideLink(mode, slidesCount - 1, { state: accept, online: setOnline, error: setError });
    linkRef.current = link;
    return link;
  }, [mode, accept]);
  const connect = useCallback(async (raw: string) => {
    let pair: {code: string; token: string};
    try { pair = credentials(raw); } catch (e) { setError((e as Error).message); return; }
    setBusy(true); setError(''); setOnline(false);
    const link = newLink();
    try {
      const state = await link.join(pair.code, pair.token);
      accept(state); history.replaceState(null, '', siteUrl(`pilot.html?kod=${pair.code}#klucz=${pair.token}`));
    } catch (e) { link.dispose(); setError(e instanceof Error ? e.message : 'Nie udało się połączyć.'); setOnline(false); }
    finally { setBusy(false); }
  }, [accept, newLink]);
  const create = useCallback(async (restore?: Session) => {
    setBusy(true); setError(''); setOnline(false);
    const link = newLink();
    try {
      const state = await link.host(localIndex, restore);
      accept(state); history.replaceState(null, '', siteUrl(`?kod=${state.code}`));
      if (!restore) setPanel('pair');
    } catch (e) { link.dispose(); sessionRef.current = null; setSession(null); setError(e instanceof Error ? e.message : 'Nie udało się uruchomić połączenia.'); }
    finally { setBusy(false); }
  }, [accept, localIndex, newLink]);
  useEffect(() => {
    if (initial.current) return; initial.current = true;
    if (mode === 'remote') {
      const query = new URLSearchParams(location.search).get('kod');
      if (query && location.hash) { setInput(location.href); void connect(location.href); }
    } else {
      const saved = storedHost(slidesCount - 1);
      if (saved) void create(saved);
    }
  }, [connect, create, mode]);
  useEffect(() => () => { linkRef.current?.dispose(); }, []);
  useEffect(() => {
    if (!session || !('wakeLock' in navigator)) return;
    let active = true;
    let lock: WakeLockSentinel | null = null;
    const keepAwake = async () => {
      if (document.visibilityState !== 'visible' || lock) return;
      try { const value = await navigator.wakeLock.request('screen'); if (!active) await value.release(); else { lock = value; value.addEventListener('release', () => { lock = null; }); } } catch { /* Browser may limit this in battery saving mode. */ }
    };
    void keepAwake(); document.addEventListener('visibilitychange', keepAwake);
    return () => { active = false; document.removeEventListener('visibilitychange', keepAwake); void lock?.release(); };
  }, [session?.code]);

  useEffect(() => {
    if (!session?.code || panel !== 'pair') return;
    let active = true;
    import('qrcode').then(({ default: QRCode }) => QRCode.toDataURL(pilotHref, { width: 256, margin: 1, color: { dark: '#352c2a', light: '#fffdf9' } })).then(value => { if (active) setQr(value); }).catch(() => { if (active) setQr(''); });
    return () => { active = false; };
  }, [session?.code, session?.token, panel, pilotHref]);
  const send = useCallback((action: Action, slide?: number) => {
    if (!sessionRef.current) {
      if (action === 'goto') setLocalIndex(slide!);
      if (action === 'next') setLocalIndex(v => Math.min(slidesCount - 1, v + 1));
      if (action === 'previous') setLocalIndex(v => Math.max(0, v - 1));
      return;
    }
    commandCount.current++; setPending(true);
    commandQueue.current = commandQueue.current.then(async () => {
      const current = sessionRef.current;
      try { if (current) accept(await linkRef.current!.command(action, slide)); }
      catch (e) { setError(e instanceof Error ? e.message : 'Nie udało się zmienić slajdu.'); setOnline(false); }
      finally { commandCount.current--; setPending(commandCount.current > 0); }
    });
  }, [accept]);
  const toggleFullscreen = useCallback(async () => {
    if (fullscreen || document.fullscreenElement) {
      setFullscreen(false);
      if (document.fullscreenElement && document.exitFullscreen) {
        try { await document.exitFullscreen(); } catch { /* Esc remains available in native fullscreen. */ }
      }
      return;
    }
    // Keep a usable presentation mode even when an embedded browser denies native fullscreen.
    setFullscreen(true);
    root.current?.focus({ preventScroll: true });
    if (document.fullscreenEnabled !== false && root.current?.requestFullscreen) {
      try { await root.current.requestFullscreen(); } catch { /* The presentation still fills the available window. */ }
    }
  }, [fullscreen]);
  useEffect(() => { const handler = () => setFullscreen(Boolean(document.fullscreenElement)); document.addEventListener('fullscreenchange', handler); return () => document.removeEventListener('fullscreenchange', handler); }, []);
  useEffect(() => {
    const keydown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLElement && ['INPUT', 'SELECT', 'TEXTAREA', 'BUTTON', 'A'].includes(e.target.tagName)) return;
      if (e.key === 'Escape') { setPanel(null); if (fullscreen) void toggleFullscreen(); return; } if (panel) return;
      if (['ArrowRight', 'PageDown', ' '].includes(e.key)) { e.preventDefault(); send('next'); }
      if (['ArrowLeft', 'PageUp'].includes(e.key)) { e.preventDefault(); send('previous'); }
      if (e.key === 'Home') { e.preventDefault(); send('goto', 0); }
      if (e.key === 'End') { e.preventDefault(); send('goto', slidesCount - 1); }
      if (e.key.toLowerCase() === 'f' && mode === 'display') void toggleFullscreen();
      if (e.key.toLowerCase() === 'b' && sessionRef.current) send('blank');
    }; window.addEventListener('keydown', keydown); return () => window.removeEventListener('keydown', keydown);
  }, [send, panel, toggleFullscreen, mode, fullscreen]);
  useEffect(() => { noteTop.current?.scrollIntoView({ behavior: 'instant', block: 'start' }); }, [index]);
  useEffect(() => {
    if (!panel) return;
    const previous = document.activeElement as HTMLElement | null;
    const dialog = document.querySelector<HTMLElement>('[role="dialog"]');
    dialog?.querySelector<HTMLElement>('button')?.focus();
    const trap = (e: KeyboardEvent) => {
      if (e.key !== 'Tab' || !dialog) return;
      const targets = Array.from(dialog.querySelectorAll<HTMLElement>('button:not(:disabled), a[href], input, select'));
      const first = targets[0], last = targets.at(-1);
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last?.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first?.focus(); }
    };
    document.addEventListener('keydown', trap);
    return () => { document.removeEventListener('keydown', trap); previous?.focus(); };
  }, [panel]);
  async function copyLink() { try { await navigator.clipboard.writeText(pilotHref); setCopyLabel('Link skopiowany'); setTimeout(() => setCopyLabel('Kopiuj link do pilota'), 2000); } catch { setError('Skopiuj link widoczny pod kodem.'); } }
  function disconnect() { linkRef.current?.forget(); linkRef.current = null; sessionRef.current = null; setSession(null); setOnline(false); setInput(''); setError(''); history.replaceState(null, '', siteUrl(mode === 'remote' ? 'pilot.html' : '')); }
  const status = session ? online ? 'Połączono' : mode === 'display' ? 'Oczekiwanie na telefon' : 'Łączenie ponownie' : 'Pilot niepołączony';
  const overlay = panel && <div className="modal-backdrop" onClick={() => setPanel(null)}><section className={`modal ${panel === 'overview' ? 'overview-modal' : ''}`} role="dialog" aria-modal="true" aria-labelledby="modal-title" onClick={e => e.stopPropagation()}><button className="close-modal" onClick={() => setPanel(null)} aria-label="Zamknij">×</button>{panel === 'pair' ? <><span className="eyebrow">Telefon jako pilot</span><h2 id="modal-title">Połącz z prezentacją</h2><p>Zeskanuj kod QR telefonem albo otwórz pełny link do pilota. Numer poniżej oznacza Twoją sesję.</p>{qr && <img className="qr-code" src={qr} alt="Kod QR otwierający pilot tej prezentacji" />}<div className="pair-code">{session?.code}</div><p className="pair-account">Pozostaw prezentację otwartą na komputerze. Najpewniejsze połączenie: wspólne Wi-Fi lub hotspot telefonu.</p><div className="pair-actions"><button className="primary-button" onClick={() => void copyLink()}>{copyLabel}</button><a className="plain-link" href={pilotHref} target="_blank" rel="noreferrer">Otwórz pilot w nowej karcie</a></div><a className="pair-url" href={typeof window !== 'undefined' ? pilotHref : pilotHref}>{pilotHref}</a></> : <><span className="eyebrow">{slidesCount} slajdów</span><h2 id="modal-title">Spis prezentacji</h2><div className="overview-list">{slides.map((s, i) => <button className={index === i ? 'active' : ''} key={s.number} onClick={() => { send('goto', i); setPanel(null); }}><span>{String(i + 1).padStart(2, '0')}</span><strong>{s.title.replace('\n', ' ')}</strong><small>{time(s.start)}</small></button>)}</div></>}</section></div>;

  if (mode === 'remote' && !session) return <main className="pilot-connect"><a className="brand" href={siteUrl()}>AI <span>&</span> prawo autorskie</a><div className="connect-content"><span className="eyebrow">Pilot prezentacji</span><h1>Twoje slajdy.<br /><em>Pod kontrolą.</em></h1><p>Otwórz prezentację na komputerze i wybierz „Połącz telefon”. Zeskanuj kod QR albo wklej pełny link do pilota.</p><form onSubmit={e => { e.preventDefault(); void connect(input); }}><label htmlFor="session-code">Link do pilota</label><input id="session-code" type="url" inputMode="url" autoComplete="off" maxLength={2048} placeholder="Wklej pełny link z prezentacji" value={input} onChange={e => setInput(e.target.value)} autoFocus /><button className="primary-button" disabled={busy || input.trim().length < 20}>{busy ? 'Łączenie…' : 'Połącz z prezentacją'}<Arrow /></button></form>{error && <p className="error-message" role="alert">{error}</p>}<p className="connect-account">Najpewniejsze połączenie: telefon i komputer w tej samej sieci Wi-Fi lub komputer podłączony do hotspotu telefonu.</p></div><footer>Ochrona własności intelektualnej · {slidesCount} slajdów</footer></main>;
  if (mode === 'remote') return <main className="pilot-app"><header className="pilot-header"><a className="brand" href={siteUrl()}>AI <span>&</span> prawo autorskie</a><button className="small-button" onClick={disconnect}>Rozłącz</button></header><div className="pilot-status"><span className={`connection-dot ${online ? 'online' : ''}`} />{status}<span className="session-label">Kod {session!.code}</span></div><RehearsalTimer /><section className="pilot-current"><div className="pilot-position"><span>Slajd {String(index + 1).padStart(2, '0')} <span className="muted">/ {slidesCount}</span></span><button className="text-button" onClick={() => setPanel('overview')}>Wybierz slajd</button></div><h1>{d.title.replace('\n', ' ')}</h1><div className="pilot-progress"><span style={{ width: `${((index + 1) / slidesCount) * 100}%` }} /></div><div className="pilot-preview"><SlideFrame index={index} preview /></div><div className="pilot-meta"><span>{d.seconds ? `Plan wystąpienia ${time(d.start)}–${time(d.end)}` : 'Bibliografia · materiał referencyjny'}</span><button className="text-button" onClick={() => send('blank')}>{session!.blank ? 'Pokaż ekran' : 'Wygasz ekran'}</button></div>{session!.blank && <p className="blank-notice">Ekran prezentacji jest wygaszony.</p>}</section><section className="speaker-notes" ref={noteTop}><div className="notes-heading"><h2>Podpowiedzi do mówienia</h2><div><button aria-label="Zmniejsz tekst" onClick={() => setNoteSize(s => Math.max(16, s - 1))}>A−</button><button aria-label="Powiększ tekst" onClick={() => setNoteSize(s => Math.min(26, s + 1))}>A+</button></div></div><div className="cue-summary" style={{ fontSize: noteSize }}><span>Główna myśl</span><p>{d.memory}</p></div>{d.cues.length > 0 && <><p className="cue-label">{d.cues.length === 3 ? 'Opowiedz w trzech krokach' : 'Plan zakończenia'}</p><ol className="speaker-cues" style={{ fontSize: noteSize }}>{d.cues.map((cue, i) => <li key={i}><span>0{i + 1}</span><p>{cue}</p></li>)}</ol></>}{d.curiosity && <aside className="speaker-curiosity" style={{fontSize:noteSize}}><span>Ciekawostka do opowiedzenia</span><p>{d.curiosity}</p></aside>}<details className="full-script" key={index}><summary>Pełny tekst wystąpienia</summary><div className="notes-body" style={{ fontSize: noteSize }}>{d.script ? d.script.split('\n\n').map((p, i) => <p key={i}>{p}</p>) : <p>Źródła i pełne opisy dokumentów znajdują się poniżej.</p>}</div></details><details className="notes-sources"><summary>Źródła tego slajdu</summary>{d.refs.map(id => { const source = sources.find(s => s.id === id)!; return <a key={id} href={source.url} target="_blank" rel="noreferrer">[{id}] {source.title}</a>; })}</details></section><footer className="pilot-dock">{error && <p className="dock-error" role="alert">{error}</p>}<div className="remote-buttons"><button disabled={index === 0 || pending} onClick={() => send('previous')}><Arrow left />Poprzedni</button><button className="primary-button" disabled={index === slidesCount - 1 || pending} onClick={() => send('next')}>{pending ? 'Zmieniam…' : index === slidesCount - 1 ? 'Ostatni slajd' : 'Następny'}<Arrow /></button></div>{index < slidesCount - 1 && <p>Następny: {slides[index + 1].title.replace('\n', ' ')}</p>}</footer>{overlay}</main>;
  return <div className={`presentation-app ${fullscreen ? 'is-fullscreen' : ''}`} ref={root} tabIndex={-1}><header className="display-topbar"><a className="brand" href={siteUrl()}>AI <span>&</span> prawo autorskie</a><div className="topbar-actions"><button className="text-button" onClick={() => setPanel('overview')}>Spis slajdów</button><a className="text-button" href={pilotHref} target="_blank" rel="noreferrer">Pilot</a><button className="pair-button" disabled={busy} onClick={() => session ? setPanel('pair') : void create()}>{busy ? 'Łączenie…' : 'Połącz telefon'}</button></div></header><main className="display-stage"><SlideFrame index={index} />{session?.blank && <div className="blackout" aria-label="Ekran wygaszony przez pilota" />}</main><footer className="display-controls"><div className="control-left"><span className={`connection-dot ${online ? 'online' : ''}`} /><span>{status}</span>{session && <span className="control-code">{session.code}</span>}</div><div className="display-navigation"><button aria-label="Poprzedni slajd" disabled={index === 0 || pending} onClick={() => send('previous')}><Arrow left /></button><span>{String(index + 1).padStart(2, '0')}<span className="muted"> / {slidesCount}</span></span><button aria-label="Następny slajd" disabled={index === slidesCount - 1 || pending} onClick={() => send('next')}><Arrow /></button></div><button className="fullscreen-button" aria-pressed={fullscreen} title="Pełny ekran · F. Wyjście · Esc" onClick={() => void toggleFullscreen()}><Expand /><span>{fullscreen ? 'Zamknij pełny ekran' : 'Pełny ekran'}</span></button></footer>{error && <div className="display-error" role="alert">{error}<button className="text-button" onClick={() => mode === 'display' ? void create() : void connect(input)}>Spróbuj ponownie</button><button onClick={() => setError('')} aria-label="Ukryj komunikat">×</button></div>}{overlay}</div>;
}
