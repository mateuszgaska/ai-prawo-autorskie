export const siteUrl = (file = '') => new URL(file || './', new URL('./', location.href)).href;
