from pathlib import Path
import re
import shutil

out = Path('dist')
html = (out / 'index.html').read_text()
def script(match):
    source = match.group(1)
    js = (out / source.removeprefix('./')).read_text()
    return '<script type="module">' + js.replace('</script', '<\\/script') + '</script>'
def style(match):
    css = (out / match.group(1).removeprefix('./')).read_text()
    return '<style>' + css + '</style>'
html = re.sub(r'<script type="module"[^>]* src="([^"]+)"[^>]*></script>', script, html)
html = re.sub(r'<link rel="stylesheet"[^>]* href="([^"]+)"[^>]*>', style, html)
(out / 'index.html').write_text(html)
(out / 'pilot.html').write_text(html)
(out / '.nojekyll').touch()
if (out / 'assets').exists():
    shutil.rmtree(out / 'assets')
assert '/api/sessions' not in html
assert 'src="./assets/' not in html
print(f'GitHub Pages: dwa samodzielne pliki HTML, po {len(html.encode()):,} B; obrazy i czcionki bez zewnętrznych pobrań.')
