import { defineConfig } from 'vite';
export default defineConfig({
  base: './',
  build: {
    assetsInlineLimit: 2_000_000,
    cssCodeSplit: false,
    rollupOptions: { output: { inlineDynamicImports: true } },
  },
});
